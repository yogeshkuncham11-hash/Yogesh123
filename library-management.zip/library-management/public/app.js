const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = d => d ? new Date(d).toLocaleDateString() : '-';
let demoOffset = 0, demo = false, curTab = null;
const vnow = () => new Date(Date.now() + demoOffset * 864e5);
const fineFor = (d, tiers) => { let f = 0, prev = 0; for (const t of tiers) { const up = t.upTo ?? Infinity; f += Math.max(0, Math.min(d, up) - prev) * t.rate; prev = up; } return f; };
const tierText = tiers => tiers.map((t, i) => { const from = i ? tiers[i - 1].upTo + 1 : 1; return t.upTo ? `late day ${from}–${t.upTo}: ₹${t.rate}/day` : `after day ${from - 1}: ₹${t.rate}/day`; }).join(' · ');
const iso = d => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
const addDays = n => iso(new Date(Date.now() + (n + demoOffset) * 864e5));
let retDate = addDays(14);
let token = localStorage.getItem('token'), user = JSON.parse(localStorage.getItem('user') || 'null');

async function api(path, method = 'GET', body) {
  const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: body && JSON.stringify(body) });
  const d = await r.json();
  if (r.status === 401 && user) logout();
  if (!r.ok) { alert(d.error || 'Error'); throw d; }
  return d;
}
function logout() { localStorage.clear(); token = user = null; init(); }
const tabs = (list, cur) => `<div class="tabs">${list.map(([k, l]) => `<button class="tab ${k === cur ? 'on' : ''}" onclick="go('${k}')">${l}</button>`).join('')}</div>`;
const table = (heads, rows) => `<div class="tw"><table><tr>${heads.map(h => `<th>${h}</th>`).join('')}</tr>${rows.join('') || `<tr><td colspan="${heads.length}" class="mute">Nothing here yet</td></tr>`}</table></div>`;

function init() {
  $('#who').innerHTML = user ? `${esc(user.name)} (${user.role}) <button class="ghost" onclick="logout()">Logout</button>` : '';
  if (!user) return loginView();
  go(user.role === 'student' ? 'catalog' : 'books');
}
function loginView() {
  $('#app').innerHTML = `<div class="card login"><h2>Login</h2>
    <input id="u" placeholder="Username"><input id="p" type="password" placeholder="Password">
    <button onclick="login()" style="width:100%;margin-top:8px">Sign in</button>
    <p class="mute">New student? <a href="#" onclick="registerView();return false">Create an account</a></p>
    <p class="mute">Librarian demo: admin / admin123</p></div>`;
}
function registerView() {
  $('#app').innerHTML = `<div class="card login"><h2>Student Registration</h2>
    <input id="rn" placeholder="Full name"><input id="ru" placeholder="Username (3-20 chars)">
    <input id="rp" type="password" placeholder="Password (min 6 chars)"><input id="rc" type="password" placeholder="Confirm password">
    <button onclick="register()" style="width:100%;margin-top:8px">Register</button>
    <p class="mute">Already registered? <a href="#" onclick="loginView();return false">Back to login</a></p></div>`;
}
function saveSession(d) {
  token = d.token; user = d.user;
  localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user));
  async function markReturned(id) { const d = await api(`/borrowals/${id}/return`, 'POST'); alert(d.lateDays ? `Late ${d.lateDays} day(s). Fine ₹${d.fine} added.` : `On time. +${d.reward} points awarded.`); go('loans'); }
const payStats = p => `<div class="card stats"><div class="stat"><b class="good">₹${p.filter(x => x.status === 'confirmed').reduce((s, x) => s + x.amount, 0)}</b>Collected</div>
  <div class="stat"><b>${p.filter(x => x.status === 'pending').length}</b>Pending</div><div class="stat"><b class="mute">₹${p.filter(x => x.status === 'refunded').reduce((s, x) => s + x.amount, 0)}</b>Refunded</div></div>`;
async function recordCash(id, fines) { const a = prompt('Cash received (₹)', fines); if (a) { await api(`/students/${id}/cash-payment`, 'POST', { amount: a }); go('students'); } }
async function addFine() { await api(`/students/${$('#fs').value}/fine`, 'POST', { amount: $('#fa').value, reason: $('#fr').value }); go('fines'); }
async function refundPay(id, amt) {
  if (!confirm(`Refund ₹${amt} to the student? (Hand the money back first.)`)) return;
  const reinstate = confirm('Also add ₹' + amt + ' back to the student\'s fine?\nOK = yes, fine is due again\nCancel = no, fine stays cleared');
  await api(`/payments/${id}/refund`, 'POST', { reinstate }); go('pay');
}
async function payAct(id, act) { await api(`/payments/${id}/${act}`, 'POST'); go('pay'); }
init();
}
async function register() {
  if ($('#rp').value !== $('#rc').value) return alert('Passwords do not match');
  saveSession(await api('/register', 'POST', { name: $('#rn').value, username: $('#ru').value, password: $('#rp').value }));
}
async function login() {
  saveSession(await api('/login', 'POST', { username: $('#u').value, password: $('#p').value }));
}
async function loadDemo() {
  const d = await api('/demo'); demo = d.enabled;
  if (d.offset !== demoOffset) { demoOffset = d.offset; retDate = addDays(14); }
}
const demoBar = () => !demo ? '' : `<div class="card"><b>⏱ Demo time machine:</b> today is ${vnow().toLocaleDateString()} (+${demoOffset} days)
  ${user.role === 'librarian' ? `<div class="row" style="margin-top:8px"><button onclick="tm(7)">Skip 7 days</button><button onclick="tm(20)">Skip 20 days</button><button class="red" onclick="tm(0)">Reset</button></div>
  <p class="mute">Skip ahead, then return a book to see fines vs reward points.</p>` : ''}</div>`;
async function tm(days) { await api('/demo', 'POST', days ? { days } : { reset: true }); go(curTab); }
const dash = s => `<div class="card stats"><div class="stat"><b>${s.totals.copies}</b>Books</div><div class="stat"><b>${s.totals.available}</b>Available</div>
  <div class="stat"><b>${s.totals.students}</b>Students</div><div class="stat"><b>${s.totals.onLoan}</b>On loan</div>
  <div class="stat"><b class="bad">${s.overdue}</b>Overdue</div><div class="stat"><b class="good">₹${s.totals.finesCollected}</b>Fines collected</div></div>`;
const importBox = (kind, cols) => `<h4 style="margin:16px 0 4px">Bulk import (CSV)</h4>
  <input type="file" accept=".csv,text/csv" onchange="importCsv('${kind}', this)"><a href="templates/${kind}.csv" download>CSV template</a> <span class="mute">columns: ${cols}</span>`;
async function importCsv(kind, el) {
  const f = el.files[0]; if (!f) return;
  const d = await api(`/${kind}/import`, 'POST', { csv: await f.text() });
  alert(`Imported ${d.added}, skipped ${d.skipped}` + (d.errors.length ? '\n\n' + d.errors.join('\n') : ''));
  go(kind);
}
async function go(t) { curTab = t; await loadDemo(); user.role === 'student' ? await studentView(t) : await librarianView(t); }

// ---------- Student ----------
async function studentView(t) {
  const T = demoBar() + tabs([['catalog', 'Catalog'], ['mine', 'My Books & Rewards'], ['returns', 'Return History'], ['history', 'Payment History']], t);
  if (t === 'catalog') {
    const books = await api('/books' + ($('#q') ? '?q=' + encodeURIComponent($('#q').value) : ''));
    $('#app').innerHTML = T + `<div class="card"><input id="q" placeholder="Search title, author, section" onchange="go('catalog')">
      <label class="mute">📅 Return date for the book you borrow (up to 30 days)</label>
      <input type="date" value="${retDate}" min="${addDays(0)}" max="${addDays(30)}" onchange="retDate=this.value">` +
      table(['Title', 'Author', 'Section', 'Available', ''], books.map(b => `<tr><td>${esc(b.title)}</td><td>${esc(b.author)}</td><td>${esc(b.section)}</td>
        <td>${b.available}/${b.total}</td><td><button ${b.available ? '' : 'disabled'} onclick="borrow(${b.id})">Borrow</button></td></tr>`)) + '</div>';
  } else if (t === 'returns') {
    const m = await api('/me'), rl = m.loans.filter(l => l.returned_at), late = rl.filter(l => l.fine > 0).length;
    $('#app').innerHTML = T + `<div class="card stats"><div class="stat"><b>${rl.length}</b>Books returned</div><div class="stat"><b class="good">${rl.length - late}</b>On time</div>
      <div class="stat"><b class="bad">${late}</b>Late</div><div class="stat"><b class="good">${m.points}</b>Reward points</div></div><div class="card">` +
      table(['Book', 'Borrowed', 'Return by', 'Returned on', 'Result'], rl.map(l => `<tr><td>${esc(l.title)}</td><td>${fmt(l.borrowed_at)}</td><td>${fmt(l.due_at)}</td><td>${fmt(l.returned_at)}</td>
        <td>${l.fine ? `<span class="bad">${l.late_days} day(s) late · fine ₹${l.fine}</span>` : `<span class="good">On time · +${l.reward} pts</span>`}</td></tr>`)) + '</div>';
  } else if (t === 'history') {
    const m = await api('/me');
    const paid = m.payments.filter(p => p.status === 'confirmed').reduce((s, p) => s + p.amount, 0);
    $('#app').innerHTML = T + `<div class="card stats"><div class="stat"><b class="good">₹${paid}</b>Total paid</div><div class="stat"><b class="bad">₹${m.fines}</b>Outstanding</div></div>
      <div class="card">` + table(['Receipt', 'Date', 'Method', 'Amount', 'Reference', 'Status'], m.payments.map(p => `<tr><td>RCPT-${String(p.id).padStart(5, '0')}</td><td>${fmt(p.created_at)}</td>
        <td>${mLabel(p.method)}</td><td>₹${p.amount}</td><td>${esc(p.utr || '-')}</td><td class="${stCls(p.status)}">${p.status}</td></tr>`)) + '</div>' +
      `<div class="card"><h3>Fine records</h3>` + table(['Date', 'Type', 'Amount', 'Reason'], m.fineLog.map(fRow)) + '</div>';
  } else {
    const m = await api('/me'), r = m.rules, now = vnow();
    $('#app').innerHTML = T + `<div class="card stats">
      <div class="stat"><b class="good">${m.points}</b>Reward points</div>
      <div class="stat"><b class="bad">₹${m.fines}</b>Fines</div></div>
      ${payCard(m)}<p class="mute">Pick your own return date when borrowing (up to ${r.MAX_LOAN_DAYS} days, default ${r.LOAN_DAYS}). Return on time = +${r.REWARD} points. Late fines → ${tierText(r.FINE_TIERS)}. Max ${r.MAX_BORROW} books.</p>
      <div class="card">` + table(['Book', 'Borrowed', 'Return by', 'Returned on', 'Status', ''], m.loans.map(l => {
        const overdue = !l.returned_at && new Date(l.due_at) < now;
        const late = Math.ceil((now - new Date(l.due_at)) / 864e5), left = Math.ceil((new Date(l.due_at) - now) / 864e5);
        return `<tr><td>${esc(l.title)}</td><td>${fmt(l.borrowed_at)}</td><td class="${overdue ? 'bad' : ''}">${fmt(l.due_at)}</td><td>${fmt(l.returned_at)}</td>
        <td>${l.returned_at ? (l.fine ? `<span class="bad">Fine ₹${l.fine}</span>` : `<span class="good">+${l.reward} pts</span>`) : overdue ? `<span class="bad">Overdue ${late}d · fine so far ₹${fineFor(late, r.FINE_TIERS)}</span>` : `${left} day(s) left`}</td>
        <td>${l.returned_at ? '' : `<button onclick="ret(${l.id})">Return</button>`}</td></tr>`; })) + '</div>';
  }
}
async function borrow(id) { const d = await api('/borrow', 'POST', { bookId: id, returnDate: retDate }); alert('Borrowed! Return by ' + fmt(d.due) + ' to earn reward points.'); go('catalog'); }
async function ret(id) {
  const d = await api('/return/' + id, 'POST');
  alert(d.lateDays ? `Returned ${d.lateDays} day(s) late. Fine: ₹${d.fine}. Please pay it now.` : `Returned on time! +${d.reward} reward points`);
  await go('mine');
  if (d.fine) $('#payBtn')?.click();
}
function payCard(m) {
  const pend = m.payments.find(p => p.status === 'pending');
  if (pend) return `<div class="card">⏳ ${mLabel(pend.method)} payment of ₹${pend.amount}${pend.utr ? ' (UTR ' + esc(pend.utr) + ')' : ''} is awaiting librarian confirmation.</div>`;
  if (!(m.fines > 0)) return '';
  return `<div class="card"><h3>Fine due: ₹${m.fines}</h3><p class="mute">Choose a payment option:</p>
    <div class="row"><button id="payBtn" onclick="showPay('upi',${m.fines},'${esc(m.upi.id)}','${esc(m.upi.name)}')">📱 UPI / QR code</button>
    <button onclick="showPay('phonepe',${m.fines},'${esc(m.upi.id)}','${esc(m.upi.name)}')">🟣 PhonePe</button>
    <button onclick="showPay('cash',${m.fines})">💵 Cash at counter</button></div><div id="pay"></div></div>`;
}
function showPay(method, amt, vpa, name) {
  if (method === 'cash') {
    $('#pay').innerHTML = `<p>Pay <b>₹${amt}</b> in cash at the library desk. Tap below to notify the librarian, who confirms once the cash is received.</p>
      <button onclick="submitPay('cash')">Request cash payment</button>`;
    return;
  }
  const link = `upi://pay?pa=${encodeURIComponent(vpa)}&pn=${encodeURIComponent(name)}&am=${amt}&cu=INR&tn=${encodeURIComponent('Library fine')}`;
  $('#pay').innerHTML = `<div id="qr" style="margin:12px 0;background:#fff;padding:10px;display:inline-block"></div>
    <p>Scan with any UPI app (GPay, PhonePe, Paytm…) or pay <b>₹${amt}</b> to <b>${esc(vpa)}</b></p>
    <p><a href="${esc(method === 'phonepe' ? link.replace('upi://', 'phonepe://') : link)}"><button>Open ${method === 'phonepe' ? 'PhonePe' : 'UPI'} app (mobile)</button></a></p>
    <p class="mute">After paying, enter the 12-digit transaction ID (UTR) from your UPI app.</p>
    <input id="utr" placeholder="12-digit UTR" maxlength="12" inputmode="numeric"><button onclick="submitPay('${method}')">I have paid</button>`;
  if (window.QRCode) new QRCode($('#qr'), { text: link, width: 180, height: 180 });
  else $('#qr').textContent = link;
}
async function submitPay(method) {
  await api('/pay', 'POST', { method, utr: method !== 'cash' ? $('#utr').value.trim() : undefined });
  alert(method === 'cash' ? 'Request sent! Pay at the desk; the librarian will confirm.' : 'Submitted! The librarian will confirm your payment.');
  go('mine');
}
const mLabel = m => m === 'cash' ? '💵 Cash' : m === 'phonepe' ? '🟣 PhonePe' : '📱 UPI';
const stCls = s => s === 'confirmed' ? 'good' : s === 'rejected' ? 'bad' : s === 'refunded' ? 'mute' : '';
const fType = { late: 'Late return', manual: 'Added by librarian', waiver: 'Waived', reinstated: 'Reinstated (refund)' };
const fRow = f => `<tr><td>${fmt(f.created_at)}</td>${f.student ? `<td>${esc(f.student)}</td>` : ''}<td>${fType[f.type] || f.type}</td>
  <td class="${f.amount < 0 ? 'good' : 'bad'}">${f.amount < 0 ? '−' : '+'}₹${Math.abs(f.amount)}</td><td>${esc(f.reason || '-')}</td></tr>`;

// ---------- Librarian ----------
async function librarianView(t) {
  const S = await api('/stats');
  const T = demoBar() + dash(S) + tabs([['books', 'Books'], ['sections', 'Sections'], ['students', 'Students'], ['loans', 'Borrowals'], ['returns', 'Return History'], ['pay', 'Payments'], ['fines', 'Fines'], ['stats', 'Overview & Logs']], t);
  const A = $('#app');
  if (t === 'books') {
    const books = await api('/books');
    A.innerHTML = T + `<div class="card"><h3>Add book / copies</h3><div class="row">
      <input id="bt" placeholder="Title"><input id="ba" placeholder="Author"><input id="bs" placeholder="Section">
      <input id="bc" type="number" min="1" value="1"><button onclick="addBook()">Add</button></div>${importBox('books', 'title,author,section,copies')}</div><div class="card">` +
      table(['Title', 'Author', 'Section', 'Available/Total', ''], books.map(b => `<tr><td>${esc(b.title)}</td><td>${esc(b.author)}</td><td>${esc(b.section)}</td>
        <td>${b.available}/${b.total}</td><td><button class="red" onclick="del('/books/${b.id}','books')">Remove</button></td></tr>`)) + '</div>';
  } else if (t === 'sections') {
    A.innerHTML = T + '<div class="card">' + table(['Section', 'Titles', 'Copies', 'Available', 'On loan'], S.sections.map(x => `<tr><td>${esc(x.section)}</td><td>${x.titles}</td><td>${x.copies}</td><td>${x.available}</td><td>${x.copies - x.available}</td></tr>`)) + '</div>';
  } else if (t === 'students') {
    const s = await api('/students');
    A.innerHTML = T + `<div class="card"><h3>Add student</h3><div class="row">
      <input id="sn" placeholder="Full name"><input id="su" placeholder="Username"><input id="sp" placeholder="Password"><button onclick="addStudent()">Add</button></div>${importBox('students', 'name,username,password')}</div><div class="card">` +
      table(['Name', 'Username', 'Active loans', 'Points', 'Fines', ''], s.map(x => `<tr><td>${esc(x.name)}</td><td>${esc(x.username)}</td><td>${x.active}</td><td>${x.points}</td><td>₹${x.fines}</td>
        <td>${x.fines ? `<button onclick="recordCash(${x.id},${x.fines})">Record cash</button> <button onclick="clearFine(${x.id})">Waive fine</button> ` : ''}<button class="red" onclick="del('/students/${x.id}','students')">Remove</button></td></tr>`)) + '</div>';
  } else if (t === 'loans') {
    const l = await api('/borrowals'), now = vnow();
    A.innerHTML = T + '<div class="card">' + table(['Student', 'Book', 'Borrowed', 'Return by', 'Returned on', 'Status', ''], l.map(b => {
      const od = !b.returned_at && new Date(b.due_at) < now;
      return `<tr><td>${esc(b.student)}</td><td>${esc(b.title)}</td><td>${fmt(b.borrowed_at)}</td><td>${fmt(b.due_at)}</td><td>${fmt(b.returned_at)}</td>
      <td>${b.returned_at ? (b.fine ? `<span class="bad">Late, fine ₹${b.fine}</span>` : '<span class="good">On time</span>') : od ? '<span class="bad">Overdue</span>' : 'Borrowed'}</td><td>${b.returned_at ? '' : `<button onclick="markReturned(${b.id})">Mark returned</button>`}</td></tr>`; })) + '</div>';
  } else if (t === 'returns') {
    const r = (await api('/borrowals')).filter(b => b.returned_at), late = r.filter(b => b.fine > 0);
    A.innerHTML = T + `<div class="card stats"><div class="stat"><b>${r.length}</b>Returned</div><div class="stat"><b class="good">${r.length - late.length}</b>On time</div>
      <div class="stat"><b class="bad">${late.length}</b>Late</div><div class="stat"><b class="bad">₹${late.reduce((s, b) => s + b.fine, 0)}</b>Fines charged</div></div><div class="card">` +
      table(['Student', 'Book', 'Borrowed', 'Return by', 'Returned on', 'Result'], r.map(b => `<tr><td>${esc(b.student)}</td><td>${esc(b.title)}</td><td>${fmt(b.borrowed_at)}</td><td>${fmt(b.due_at)}</td><td>${fmt(b.returned_at)}</td>
        <td>${b.fine ? `<span class="bad">Late ${b.late_days}d · fine ₹${b.fine}</span>` : `<span class="good">On time · +${b.reward} pts</span>`}</td></tr>`)) + '</div>';
  } else if (t === 'pay') {
    const p = await api('/payments');
    A.innerHTML = T + payStats(p) + '<div class="card"><p class="mute">UPI: check the UTR in your bank app. Cash: confirm only after receiving it.</p>' + table(['Date', 'Student', 'Method', 'Amount', 'Reference', 'Status', ''], p.map(x => `<tr><td>${fmt(x.created_at)}</td><td>${esc(x.student)}</td><td>${mLabel(x.method)}</td><td>₹${x.amount}</td><td>${esc(x.utr || '-')}</td>
      <td class="${stCls(x.status)}">${x.status}</td>
      <td>${x.status === 'pending' ? `<button onclick="payAct(${x.id},'confirm')">Confirm</button> <button class="red" onclick="payAct(${x.id},'reject')">Reject</button>` : x.status === 'confirmed' ? `<button class="red" onclick="refundPay(${x.id},${x.amount})">Refund</button>` : ''}</td></tr>`)) + '</div>';
  } else if (t === 'fines') {
    const [f, s] = await Promise.all([api('/fines'), api('/students')]);
    A.innerHTML = T + `<div class="card"><h3>Add a fine (damaged / lost book, etc.)</h3><div class="row">
      <select id="fs">${s.map(x => `<option value="${x.id}">${esc(x.name)} (due ₹${x.fines})</option>`).join('')}</select>
      <input id="fa" type="number" min="1" placeholder="Amount ₹"><input id="fr" placeholder="Reason"><button onclick="addFine()">Add fine</button></div>
      <p class="mute">Late-return fines are added automatically when a book is returned.</p></div>
      <div class="card"><h3>Fine records</h3>` + table(['Date', 'Student', 'Type', 'Amount', 'Reason'], f.map(fRow)) + '</div>';
  } else {
    const s = S;
    A.innerHTML = T + `<div class="card stats">
      <div class="stat"><b>${s.totals.titles}</b>Titles</div><div class="stat"><b>${s.totals.copies}</b>Total copies</div>
      <div class="stat"><b>${s.totals.available}</b>Available</div><div class="stat"><b class="bad">${s.overdue}</b>Overdue</div></div>
      <div class="card"><h3>Section-wise</h3>` + table(['Section', 'Titles', 'Copies', 'Available'], s.sections.map(x => `<tr><td>${esc(x.section)}</td><td>${x.titles}</td><td>${x.copies}</td><td>${x.available}</td></tr>`)) +
      `</div><div class="card"><h3>Recent activity (MongoDB)</h3>` + table(['Time', 'User', 'Action', 'Detail'], s.logs.map(g => `<tr><td>${new Date(g.at).toLocaleString()}</td><td>${esc(g.user)}</td><td>${esc(g.action)}</td><td>${esc(JSON.stringify(g.detail))}</td></tr>`)) + '</div>';
  }
}
const val = id => $('#' + id).value.trim();
async function addBook() { await api('/books', 'POST', { title: val('bt'), author: val('ba'), section: val('bs'), copies: val('bc') }); go('books'); }
async function addStudent() { await api('/students', 'POST', { name: val('sn'), username: val('su'), password: val('sp') }); go('students'); }
async function del(path, tab) { if (confirm('Are you sure?')) { await api(path, 'DELETE'); go(tab); } }
async function clearFine(id) { await api(`/students/${id}/clear-fine`, 'POST'); go('students'); }
async function markReturned(id) { const d = await api(`/borrowals/${id}/return`, 'POST'); alert(d.lateDays ? `Late ${d.lateDays} day(s). Fine ₹${d.fine} added.` : `On time. +${d.reward} points awarded.`); go('loans'); }
async function payAct(id, act) { await api(`/payments/${id}/${act}`, 'POST'); go('pay'); }
init();

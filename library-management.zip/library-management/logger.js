// NoSQL layer (MongoDB) – activity/audit log. Falls back to memory if no MONGO_URI.
const mongoose = require('mongoose');
const mem = [];
let Log = null;
if (process.env.MONGO_URI) {
  mongoose.connect(process.env.MONGO_URI).then(() => console.log('MongoDB connected'))
    .catch(e => console.log('MongoDB failed, using memory logs:', e.message));
  Log = mongoose.model('Log', new mongoose.Schema({
    action: String, user: String, detail: Object, at: { type: Date, default: Date.now } }));
}
const ready = () => Log && mongoose.connection.readyState === 1;
exports.add = async (action, user, detail = {}) => {
  const e = { action, user, detail, at: new Date() };
  try { ready() ? await Log.create(e) : mem.unshift(e); } catch { mem.unshift(e); }
};
exports.list = async () => ready() ? Log.find().sort({ at: -1 }).limit(50).lean() : mem.slice(0, 50);

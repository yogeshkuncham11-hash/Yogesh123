// SQL layer (SQLite) – users, books, borrowals
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const db = new Database('library.db');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password TEXT NOT NULL,
  role TEXT CHECK(role IN ('student','librarian')) NOT NULL,
  points INTEGER DEFAULT 0, fines REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS books(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL, author TEXT NOT NULL, section TEXT NOT NULL,
  total INTEGER NOT NULL, available INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS borrowals(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES users(id),
  book_id INTEGER NOT NULL REFERENCES books(id),
  borrowed_at TEXT NOT NULL, due_at TEXT NOT NULL, returned_at TEXT,
  fine REAL DEFAULT 0, reward INTEGER DEFAULT 0, late_days INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES users(id),
  amount REAL NOT NULL, utr TEXT UNIQUE,
  method TEXT DEFAULT 'upi', status TEXT DEFAULT 'pending',
  created_at TEXT NOT NULL, confirmed_at TEXT, refunded_at TEXT);
CREATE TABLE IF NOT EXISTS fine_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES users(id),
  amount REAL NOT NULL, type TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL);
`);
try { db.exec('ALTER TABLE borrowals ADD COLUMN late_days INTEGER DEFAULT 0'); } catch {}
// Upgrade path for databases created by an older version
for (const c of ["method TEXT DEFAULT 'upi'", 'confirmed_at TEXT', 'refunded_at TEXT']) { try { db.exec('ALTER TABLE payments ADD COLUMN ' + c); } catch {} }
if (!db.prepare("SELECT 1 FROM users WHERE role='librarian'").get()) {
  db.prepare("INSERT INTO users(username,name,password,role) VALUES(?,?,?,?)")
    .run('admin', 'Head Librarian', bcrypt.hashSync('admin123', 10), 'librarian');
  const ins = db.prepare("INSERT INTO books(title,author,section,total,available) VALUES(?,?,?,?,?)");
  [['Clean Code','Robert Martin','Computer Science',3],['Sapiens','Yuval Harari','History',2],
   ['A Brief History of Time','Stephen Hawking','Science',2]].forEach(b => ins.run(...b, b[3]));
}
module.exports = db;

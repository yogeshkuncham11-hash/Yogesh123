require('dotenv').config();
const express = require('express'), jwt = require('jsonwebtoken'), bcrypt = require('bcryptjs'), path = require('path');
const db = require('./db'), logger = require('./logger');

const SECRET = process.env.JWT_SECRET || 'dev-secret';
const LOAN_DAYS = 14, MAX_LOAN_DAYS = 30, REWARD = 10, MAX_BORROW = 3;
// Demo "time machine": shifts the app's date forward so fines/rewards can be tested (enable with DEMO_MODE=true)
const DEMO = process.env.DEMO_MODE === 'true';
let dayOffset = 0;
const vnow = () => new Date(Date.now() + dayOffset * 864e5);

// Tiered late fine (₹ per late day). Edit these to change the policy.
const FINE_TIERS = [
  { upTo: 7, rate: 2 },         // late days 1-7   -> ₹2/day
  { upTo: 20, rate: 5 },        // late days 8-20  -> ₹5/day
  { upTo: Infinity, rate: 10 }, // after day 20    -> ₹10/day
];
function calcFine(days) {
  let fine = 0, prev = 0;
  for (const t of FINE_TIERS) { fine += Math.max(0, Math.min(days, t.upTo) - prev) * t.rate; prev = t.upTo; }
  return fine;
}

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const auth = role => (req, res, next) => {
  try {
    const u = jwt.verify((req.headers.authorization || '').slice(7), SECRET);
    if (role && u.role !== role) return res.status(403).json({ error: 'Forbidden' });
    req.user = u; next();
  } catch { res.status(401).json({ error: 'Please log in' }); }
};

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(username || '');
  if (!u || !bcrypt.compareSync(password || '', u.password)) return res.status(400).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: u.id, role: u.role, name: u.name }, SECRET, { expiresIn: '8h' });
  logger.add('login', u.username);
  res.json({ token, user: { id: u.id, name: u.name, role: u.role } });
});

app.post('/api/register', (req, res) => {
  const name = (req.body.name || '').trim(), username = (req.body.username || '').trim(), password = req.body.password || '';
  if (!name || !username || !password) return res.status(400).json({ error: 'All fields are required' });
  if (!/^[a-zA-Z0-9_.]{3,20}$/.test(username)) return res.status(400).json({ error: 'Username: 3-20 letters, numbers, . or _' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
  let id;
  try {
    id = db.prepare("INSERT INTO users(username,name,password,role) VALUES(?,?,?,'student')").run(username, name, bcrypt.hashSync(password, 10)).lastInsertRowid;
  } catch { return res.status(400).json({ error: 'Username already taken' }); }
  logger.add('register', username);
  const token = jwt.sign({ id, role: 'student', name }, SECRET, { expiresIn: '8h' });
  res.json({ token, user: { id, name, role: 'student' } });
});

// ---------- Demo time machine ----------
app.get('/api/demo', auth(), (req, res) => res.json({ enabled: DEMO, offset: dayOffset, today: vnow().toISOString() }));
app.post('/api/demo', auth('librarian'), (req, res) => {
  if (!DEMO) return res.status(403).json({ error: 'Demo mode is off (set DEMO_MODE=true in .env)' });
  const days = Number(req.body.days);
  if (req.body.reset) dayOffset = 0;
  else if (days > 0 && days <= 365) dayOffset += days;
  else return res.status(400).json({ error: 'Invalid days' });
  logger.add('demo_time', req.user.name, { offset: dayOffset });
  res.json({ offset: dayOffset, today: vnow().toISOString() });
});

// ---------- Shared ----------
app.get('/api/books', auth(), (req, res) => {
  const q = `%${req.query.q || ''}%`;
  res.json(db.prepare('SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR section LIKE ? ORDER BY section,title').all(q, q, q));
});

// ---------- Student ----------
app.get('/api/me', auth('student'), (req, res) => {
  const me = db.prepare('SELECT name,points,fines FROM users WHERE id=?').get(req.user.id);
  const loans = db.prepare(`SELECT b.*,k.title,k.author FROM borrowals b JOIN books k ON k.id=b.book_id
    WHERE student_id=? ORDER BY b.id DESC`).all(req.user.id);
  const payments = db.prepare('SELECT * FROM payments WHERE student_id=? ORDER BY id DESC').all(req.user.id);
  const fineLog = db.prepare('SELECT * FROM fine_log WHERE student_id=? ORDER BY id DESC').all(req.user.id);
  res.json({ ...me, loans, payments, fineLog, rules: { LOAN_DAYS, MAX_LOAN_DAYS, REWARD, MAX_BORROW,
      FINE_TIERS: FINE_TIERS.map(t => ({ upTo: isFinite(t.upTo) ? t.upTo : null, rate: t.rate })) },
    upi: { id: process.env.UPI_ID || 'library@upi', name: process.env.UPI_NAME || 'City Library' } });
});

app.post('/api/borrow', auth('student'), (req, res) => {
  const book = db.prepare('SELECT * FROM books WHERE id=?').get(req.body.bookId);
  if (!book) return res.status(404).json({ error: 'Book not found' });
  if (book.available < 1) return res.status(400).json({ error: 'No copies available' });
  const active = db.prepare('SELECT COUNT(*) c FROM borrowals WHERE student_id=? AND returned_at IS NULL').get(req.user.id).c;
  if (active >= MAX_BORROW) return res.status(400).json({ error: `Max ${MAX_BORROW} books at a time` });
  if (db.prepare('SELECT 1 FROM borrowals WHERE student_id=? AND book_id=? AND returned_at IS NULL').get(req.user.id, book.id))
    return res.status(400).json({ error: 'You already have this book' });
  // Student chooses the return date (YYYY-MM-DD); default is LOAN_DAYS from today
  const now = vnow(), rd = req.body.returnDate;
  if (rd && !/^\d{4}-\d{2}-\d{2}$/.test(rd)) return res.status(400).json({ error: 'Invalid return date' });
  const due = rd ? new Date(rd + 'T23:59:59') : new Date(now.getTime() + LOAN_DAYS * 864e5);
  const span = Math.ceil((due - now) / 864e5);
  if (isNaN(due) || span < 1 || span > MAX_LOAN_DAYS) return res.status(400).json({ error: `Return date must be within the next ${MAX_LOAN_DAYS} days` });
  db.prepare('INSERT INTO borrowals(student_id,book_id,borrowed_at,due_at) VALUES(?,?,?,?)')
    .run(req.user.id, book.id, now.toISOString(), due.toISOString());
  db.prepare('UPDATE books SET available=available-1 WHERE id=?').run(book.id);
  logger.add('borrow', req.user.name, { book: book.title });
  res.json({ ok: true, due: due.toISOString() });
});

// Minimal CSV parser (handles quotes, commas in quotes, CRLF)
function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  const endRow = () => { row.push(cell); cell = ''; if (row.some(x => x.trim())) rows.push(row.map(x => x.trim())); row = []; };
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; endRow(); }
    else cell += c;
  }
  endRow();
  return rows;
}

// Fine ledger: late / manual / waiver (negative) / reinstated
function addFineLog(studentId, amount, type, reason) {
  db.prepare('INSERT INTO fine_log(student_id,amount,type,reason,created_at) VALUES(?,?,?,?,?)').run(studentId, amount, type, reason, new Date().toISOString());
}

// Shared return logic: reward if on time, fine if late
function doReturn(b, actor) {
  const now = vnow();
  const lateDays = Math.max(0, Math.ceil((now - new Date(b.due_at)) / 864e5));
  const fine = calcFine(lateDays), reward = lateDays ? 0 : REWARD;
  db.prepare('UPDATE borrowals SET returned_at=?,fine=?,reward=?,late_days=? WHERE id=?').run(now.toISOString(), fine, reward, lateDays, b.id);
  db.prepare('UPDATE books SET available=available+1 WHERE id=?').run(b.book_id);
  db.prepare('UPDATE users SET points=points+?,fines=fines+? WHERE id=?').run(reward, fine, b.student_id);
  if (fine > 0) addFineLog(b.student_id, fine, 'late', `${lateDays} day(s) late: ${db.prepare('SELECT title FROM books WHERE id=?').get(b.book_id).title}`);
  logger.add('return', actor, { borrowal: b.id, lateDays, fine, reward });
  return { lateDays, fine, reward };
}

app.post('/api/return/:id', auth('student'), (req, res) => {
  const b = db.prepare('SELECT * FROM borrowals WHERE id=? AND student_id=? AND returned_at IS NULL').get(req.params.id, req.user.id);
  if (!b) return res.status(404).json({ error: 'Active borrowal not found' });
  res.json(doReturn(b, req.user.name));
});

// Student submits UPI payment reference (UTR) for pending fines; librarian confirms
app.post('/api/pay', auth('student'), (req, res) => {
  const u = db.prepare('SELECT fines FROM users WHERE id=?').get(req.user.id);
  const method = ['cash', 'phonepe'].includes(req.body.method) ? req.body.method : 'upi';
  let utr = null;
  if (!(u.fines > 0)) return res.status(400).json({ error: 'No fines due' });
  if (db.prepare("SELECT 1 FROM payments WHERE student_id=? AND status='pending'").get(req.user.id))
    return res.status(400).json({ error: 'A payment is already awaiting confirmation' });
  if (method !== 'cash') {
    utr = (req.body.utr || '').trim();
    if (!/^\d{12}$/.test(utr)) return res.status(400).json({ error: 'Enter a valid 12-digit UPI transaction ID (UTR)' });
    if (db.prepare('SELECT 1 FROM payments WHERE utr=?').get(utr)) return res.status(400).json({ error: 'This UTR was already used' });
  }
  db.prepare('INSERT INTO payments(student_id,amount,utr,method,created_at) VALUES(?,?,?,?,?)').run(req.user.id, u.fines, utr, method, new Date().toISOString());
  logger.add('payment_submitted', req.user.name, { amount: u.fines, method, utr });
  res.json({ ok: true });
});

// ---------- Librarian ----------
const lib = auth('librarian');

app.post('/api/books', lib, (req, res) => {
  const { title, author, section } = req.body, n = parseInt(req.body.copies, 10);
  if (!title || !author || !section || !(n > 0)) return res.status(400).json({ error: 'All fields required' });
  const ex = db.prepare('SELECT * FROM books WHERE title=? AND author=?').get(title, author);
  if (ex) db.prepare('UPDATE books SET total=total+?,available=available+? WHERE id=?').run(n, n, ex.id);
  else db.prepare('INSERT INTO books(title,author,section,total,available) VALUES(?,?,?,?,?)').run(title, author, section, n, n);
  logger.add('add_book', req.user.name, { title, copies: n });
  res.json({ ok: true });
});

app.delete('/api/books/:id', lib, (req, res) => {
  if (db.prepare('SELECT 1 FROM borrowals WHERE book_id=? AND returned_at IS NULL').get(req.params.id))
    return res.status(400).json({ error: 'Book is currently borrowed' });
  db.prepare('DELETE FROM borrowals WHERE book_id=?').run(req.params.id);
  db.prepare('DELETE FROM books WHERE id=?').run(req.params.id);
  logger.add('remove_book', req.user.name, { id: req.params.id });
  res.json({ ok: true });
});

app.get('/api/students', lib, (req, res) =>
  res.json(db.prepare(`SELECT id,username,name,points,fines,
    (SELECT COUNT(*) FROM borrowals WHERE student_id=users.id AND returned_at IS NULL) active
    FROM users WHERE role='student' ORDER BY name`).all()));

app.post('/api/students', lib, (req, res) => {
  const { username, name, password } = req.body;
  if (!username || !name || !password) return res.status(400).json({ error: 'All fields required' });
  try {
    db.prepare("INSERT INTO users(username,name,password,role) VALUES(?,?,?,'student')").run(username, name, bcrypt.hashSync(password, 10));
  } catch { return res.status(400).json({ error: 'Username already exists' }); }
  logger.add('add_student', req.user.name, { username });
  res.json({ ok: true });
});

app.delete('/api/students/:id', lib, (req, res) => {
  if (db.prepare('SELECT 1 FROM borrowals WHERE student_id=? AND returned_at IS NULL').get(req.params.id))
    return res.status(400).json({ error: 'Student has unreturned books' });
  db.prepare('DELETE FROM borrowals WHERE student_id=?').run(req.params.id);
  db.prepare("DELETE FROM users WHERE id=? AND role='student'").run(req.params.id);
  logger.add('remove_student', req.user.name, { id: req.params.id });
  res.json({ ok: true });
});

app.post('/api/students/:id/clear-fine', lib, (req, res) => {
  const u = db.prepare('SELECT fines FROM users WHERE id=?').get(req.params.id);
  if (u && u.fines > 0) addFineLog(req.params.id, -u.fines, 'waiver', 'Waived by librarian');
  db.prepare('UPDATE users SET fines=0 WHERE id=?').run(req.params.id);
  logger.add('clear_fine', req.user.name, { id: req.params.id });
  res.json({ ok: true });
});

app.post('/api/borrowals/:id/return', lib, (req, res) => {
  const b = db.prepare('SELECT * FROM borrowals WHERE id=? AND returned_at IS NULL').get(req.params.id);
  if (!b) return res.status(404).json({ error: 'Active borrowal not found' });
  res.json(doReturn(b, req.user.name + ' (librarian)'));
});

// Librarian records cash received directly at the desk (confirmed immediately)
app.post('/api/students/:id/cash-payment', lib, (req, res) => {
  const u = db.prepare("SELECT id,name,fines FROM users WHERE id=? AND role='student'").get(req.params.id);
  if (!u) return res.status(404).json({ error: 'Student not found' });
  const amt = Number(req.body.amount);
  if (!(amt > 0) || amt > u.fines) return res.status(400).json({ error: 'Enter an amount between 1 and the fine due' });
  const now = new Date().toISOString();
  db.prepare("INSERT INTO payments(student_id,amount,utr,method,status,created_at,confirmed_at) VALUES(?,?,NULL,'cash','confirmed',?,?)").run(u.id, amt, now, now);
  db.prepare('UPDATE users SET fines=fines-? WHERE id=?').run(amt, u.id);
  logger.add('cash_payment', req.user.name, { student: u.name, amount: amt });
  res.json({ ok: true });
});

// ---------- Bulk CSV import ----------
app.post('/api/students/import', lib, (req, res) => {
  const rows = parseCsv(String(req.body.csv || ''));
  if (rows.length && /^name$/i.test(rows[0][0])) rows.shift();
  if (!rows.length) return res.status(400).json({ error: 'CSV is empty' });
  if (rows.length > 200) return res.status(400).json({ error: 'Max 200 rows per import' });
  const ins = db.prepare("INSERT INTO users(username,name,password,role) VALUES(?,?,?,'student')");
  let added = 0; const errors = [];
  rows.forEach(([name, username, password], i) => {
    const line = i + 1;
    if (!name || !username || !password) return errors.push(`Row ${line}: missing value`);
    if (!/^[a-zA-Z0-9_.]{3,20}$/.test(username)) return errors.push(`Row ${line}: invalid username "${username}"`);
    if (password.length < 6) return errors.push(`Row ${line}: password must be 6+ characters`);
    try { ins.run(username, name, bcrypt.hashSync(password, 10)); added++; }
    catch { errors.push(`Row ${line}: username "${username}" already exists`); }
  });
  logger.add('import_students', req.user.name, { added, skipped: errors.length });
  res.json({ added, skipped: errors.length, errors: errors.slice(0, 10) });
});

app.post('/api/books/import', lib, (req, res) => {
  const rows = parseCsv(String(req.body.csv || ''));
  if (rows.length && /^title$/i.test(rows[0][0])) rows.shift();
  if (!rows.length) return res.status(400).json({ error: 'CSV is empty' });
  if (rows.length > 500) return res.status(400).json({ error: 'Max 500 rows per import' });
  let added = 0; const errors = [];
  rows.forEach(([title, author, section, copies], i) => {
    const n = parseInt(copies, 10);
    if (!title || !author || !section || !(n > 0)) return errors.push(`Row ${i + 1}: title, author, section and copies (number) are required`);
    const ex = db.prepare('SELECT id FROM books WHERE title=? AND author=?').get(title, author);
    if (ex) db.prepare('UPDATE books SET total=total+?,available=available+? WHERE id=?').run(n, n, ex.id);
    else db.prepare('INSERT INTO books(title,author,section,total,available) VALUES(?,?,?,?,?)').run(title, author, section, n, n);
    added++;
  });
  logger.add('import_books', req.user.name, { added, skipped: errors.length });
  res.json({ added, skipped: errors.length, errors: errors.slice(0, 10) });
});

// Librarian adds a manual fine (damaged / lost book, etc.)
app.post('/api/students/:id/fine', lib, (req, res) => {
  const u = db.prepare("SELECT id,name FROM users WHERE id=? AND role='student'").get(req.params.id);
  const amt = Number(req.body.amount), reason = (req.body.reason || '').trim().slice(0, 200);
  if (!u) return res.status(404).json({ error: 'Student not found' });
  if (!(amt > 0) || amt > 10000) return res.status(400).json({ error: 'Enter a valid amount (1-10000)' });
  if (!reason) return res.status(400).json({ error: 'Reason is required' });
  db.prepare('UPDATE users SET fines=fines+? WHERE id=?').run(amt, u.id);
  addFineLog(u.id, amt, 'manual', reason);
  logger.add('manual_fine', req.user.name, { student: u.name, amount: amt, reason });
  res.json({ ok: true });
});

app.get('/api/fines', lib, (req, res) =>
  res.json(db.prepare('SELECT f.*,u.name student FROM fine_log f JOIN users u ON u.id=f.student_id ORDER BY f.id DESC LIMIT 200').all()));

// Librarian refunds a confirmed payment (money handed back); optionally reinstates the fine
app.post('/api/payments/:id/refund', lib, (req, res) => {
  const p = db.prepare("SELECT * FROM payments WHERE id=? AND status='confirmed'").get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Confirmed payment not found' });
  const reinstate = !!req.body.reinstate;
  db.prepare("UPDATE payments SET status='refunded',refunded_at=? WHERE id=?").run(new Date().toISOString(), p.id);
  if (reinstate) {
    db.prepare('UPDATE users SET fines=fines+? WHERE id=?').run(p.amount, p.student_id);
    addFineLog(p.student_id, p.amount, 'reinstated', 'Payment refunded – fine reinstated');
  }
  logger.add('refund', req.user.name, { payment: p.id, amount: p.amount, reinstate });
  res.json({ ok: true });
});

app.get('/api/payments', lib, (req, res) =>
  res.json(db.prepare(`SELECT p.*,u.name student FROM payments p JOIN users u ON u.id=p.student_id ORDER BY p.id DESC LIMIT 100`).all()));

app.post('/api/payments/:id/:action(confirm|reject)', lib, (req, res) => {
  const p = db.prepare("SELECT * FROM payments WHERE id=? AND status='pending'").get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Pending payment not found' });
  const ok = req.params.action === 'confirm';
  db.prepare('UPDATE payments SET status=?,confirmed_at=? WHERE id=?').run(ok ? 'confirmed' : 'rejected', new Date().toISOString(), p.id);
  if (ok) db.prepare('UPDATE users SET fines=MAX(0,fines-?) WHERE id=?').run(p.amount, p.student_id);
  logger.add('payment_' + req.params.action, req.user.name, { id: p.id, amount: p.amount });
  res.json({ ok: true });
});

app.get('/api/borrowals', lib, (req, res) =>
  res.json(db.prepare(`SELECT b.*,u.name student,k.title FROM borrowals b
    JOIN users u ON u.id=b.student_id JOIN books k ON k.id=b.book_id ORDER BY b.id DESC LIMIT 200`).all()));

app.get('/api/stats', lib, async (req, res) => {
  res.json({
    totals: {
      ...db.prepare(`SELECT COALESCE(SUM(total),0) copies,COALESCE(SUM(available),0) available,COUNT(*) titles FROM books`).get(),
      students: db.prepare("SELECT COUNT(*) c FROM users WHERE role='student'").get().c,
      onLoan: db.prepare('SELECT COUNT(*) c FROM borrowals WHERE returned_at IS NULL').get().c,
      finesCollected: db.prepare("SELECT COALESCE(SUM(amount),0) c FROM payments WHERE status='confirmed'").get().c
    },
    sections: db.prepare(`SELECT section,COUNT(*) titles,SUM(total) copies,SUM(available) available FROM books GROUP BY section`).all(),
    overdue: db.prepare(`SELECT COUNT(*) c FROM borrowals WHERE returned_at IS NULL AND due_at < ?`).get(vnow().toISOString()).c,
    logs: await logger.list()
  });
});

app.listen(process.env.PORT || 3000, () => console.log('Running on http://localhost:' + (process.env.PORT || 3000)));
